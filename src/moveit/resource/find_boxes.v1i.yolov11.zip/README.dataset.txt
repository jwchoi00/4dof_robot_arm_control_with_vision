# find_boxes > 2024-12-21 10:21am
https://universe.roboflow.com/fullfilemt/find_boxes

Provided by a Roboflow user
License: CC BY 4.0

